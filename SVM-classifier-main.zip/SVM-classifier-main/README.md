# SVM-classifier
A classification problem using Support Vector machine algorithm 
